% shift the rows of H such that the top rank(H) rows has full row rank, 
% then truncate H: H=H(1:rank(H),:)

function H=rowshift(H)
[m,n]=size(H);
if rank(H)==m
    return;
end
for i=1:rank(H)
    for j=i+1:m
        if rank(H(1:i,:))==i
            break;
        end
        temp=H(j,:);
        H(j,:)=H(i,:);
        H(i,:)=temp;
    end
end
H=H(1:rank(H),:);