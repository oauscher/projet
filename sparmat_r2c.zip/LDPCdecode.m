% LDPC decode algorithm.
% Use the "sum-product decoder" described in reference [4].
% 1.	Initialization. Assign initial values to the probability matrix q0 and q1.
% 2.	Horizontal step. Use q0 and q1 to update the probability matrix r0 and r1.
% 3.	Vertical step. Use r0 and r1 to update q0 and q1.
% 4.	Estimate the error vector and compute the syndrome.
% The algorithm iterates through step 2 to step 4. 
% The iteration stops when the estimated syndrome is the same as the received syndrome (z)
% or when the number of iterations exceeds a certain value (maxiter).

function [t_est,iter]=LDPCdecode(r,H_row,H_col,H_rw,H_cw,m,n,fn,maxiter)
iter=0;
%calculate syndrome z
z=zeros(m,1);
for i=1:m
    for j=1:H_rw(i)
        z(i)=mod(z(i)+r(H_row(i,j)),2);
    end
end
if z==zeros(m,1)
    t_est=r;
    return;
end
q0=zeros(m,n);
q1=zeros(m,n);
r0=zeros(m,n);
r1=zeros(m,n);
deltaq=zeros(m,n);
%initialize q0,q1
for i=1:m
    for j=1:H_rw(i)
        q0(i,H_row(i,j))=1-fn;
        q1(i,H_row(i,j))=fn;
    end
end
% iterations
while 1
    %calculate deltaq
    for i=1:m
        for j=1:H_rw(i)
            deltaq(i,H_row(i,j))=q0(i,H_row(i,j))-q1(i,H_row(i,j));
        end
    end
    %update r0,r1
    for i=1:m
        for j=1:H_rw(i)
            deltar=(-1)^z(i);
            for l=1:H_rw(i)
                if l~=j
                    deltar=deltar*deltaq(i,H_row(i,l));
                end
            end
            r0(i,H_row(i,j))=(1+deltar)/2;
            r1(i,H_row(i,j))=(1-deltar)/2;
        end
    end
    %update q0,q1
    for i=1:n
        for j=1:H_cw(i)
            q0(H_col(j,i),i)=1-fn;
            q1(H_col(j,i),i)=fn;
            for l=1:H_cw(i)
                if l~=j
                    q0(H_col(j,i),i)=q0(H_col(j,i),i)*r0(H_col(l,i),i);
                    q1(H_col(j,i),i)=q1(H_col(j,i),i)*r1(H_col(l,i),i);
                end
            end
            q0(H_col(j,i),i)=q0(H_col(j,i),i)/(q1(H_col(j,i),i)+q0(H_col(j,i),i));
            q1(H_col(j,i),i)=1-q0(H_col(j,i),i);
        end
    end
    % Estimate the error vector and compute the syndrome.
    x=zeros(n,1);
    z2=zeros(m,1);
    for i=1:n
        if q0(H_col(1,i),i)*r0(H_col(1,i),i)<q1(H_col(1,i),i)*r1(H_col(1,i),i)
            x(i)=1;
        end
    end
    for i=1:m
        for j=1:H_rw(i)
            z2(i)=mod(z2(i)+x(H_row(i,j)),2);
        end
    end
    iter=iter+1;
    %determine whether to stop
    if sum(z2==z)==m
        t_est=mod(r-x,2);
        return;
    end
    if  iter>=maxiter
        t_est=r;
        return;
    end
end
        