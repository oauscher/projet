% covert a sparse matrix represented by column coordinate of non-zero entries for each row to the sparse matrix represented by row coordinate of non-zero entries for each column.
% H_row: sparse matrix represented by column coordinate of non-zero entries for each row.
% rw: the row weight vector of H_row.
% cw: the column weight vector of H_row
% maxrw: the maximum entry in rw.
% maxcw: the maximum entry in cw.
% [m,n]: the size of H. 
% H_col: sparse matrix represented by row coordinate of non-zero entries for each column.
% For example, if H_row=[1,4 
%                        3,0]
% then H_col=[1,0,2,1,0]

function H_col=sparmat_r2c(H_row,rw,cw,maxrw,maxcw,m,n)
H=spar2mat(H_row,rw,m,n);
H_col=zeros(maxcw,n);
for i=1:n
    ind=1;
    for j=1:m
        if H(j,i)==1
           H_col(ind,i)=j;
           ind=ind+1;
        end
    end
end
return