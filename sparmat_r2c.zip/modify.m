% flip some entries in H such that the right hand square sub-matrix of H has full rank.

function H=modify(H)
[m,n]=size(H);
k=n-m;
r=rank(H(:,k+1:n));
for i=k+1:n
    for j=1:m
        if H(j,i)==0
            H(j,i)=1;
            if rank(H(:,k+1:n))==r+1
                r=r+1;
                break;
            else
                H(j,i)=0;
            end
        end
    end
end