% bpsk demodulation

function r=dbpsk(waverx)
r=(waverx>=0);
return