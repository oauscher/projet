% LDPC encoder
% GT_row: the sparse matrix of transpose of generator matrix.
% GT_rw: the row weight vector of GT_row.
% s: information sequence.
% k: the length of information sequence.
% n: the length of coded word.

function t=LDPCencode(GT_row,s,GT_rw,k,n)
t=zeros(n,1);
t(1:k)=s;
for i=k+1:n
    if GT_rw(i)>0
        for j=1:GT_rw(i)
            t(i)=mod(t(i)+s(GT_row(i,j)),2);
        end
    end
end