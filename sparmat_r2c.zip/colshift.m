% shift the columns of H such that the right hand square sub-matrix of H has full rank.

function H=colshift(H)
[m,n]=size(H);
for i=n:-1:n-m+1
    for j=i-1:-1:1
        if rank(H(:,i:end))==n-i+1
            break;
        end
        temp=H(:,j);
        H(:,j)=H(:,i);
        H(:,i)=temp;
    end
end