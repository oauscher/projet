% derive the generator matrix G of the parity check matrix with systematic form
% Hsys: parity check matrix with systematic form

function G=getG(Hsys)
[m,n]=size(Hsys);
k=n-m;
G=[diag(ones(1,k)),Hsys(:,1:k)'];
end