% Convert a sparse matrix H_row to a normal matrix H
% H_row: sparse matrix represented by column coordinate of non-zero entries for each row. 
% rw: the row weight vector of H_row. 
% [m,n]: the size of H. 
% For example, if H_row=[1,4  , H_rw=[2  , m=2, n=5
%                        3,0]         1]
% then, H=[1,0,0,1,0
%          0,0,1,0,0]

function H=spar2mat(H_row,rw,m,n)
H=zeros(m,n);
for i=1:m
    for j=1:rw(i)
        H(i,H_row(i,j))=1;
    end
end
return
