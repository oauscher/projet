% LDPC simulator. 
% 1. Generate a parity check matrix and derive its generator matrix.
% 2. Generate an information sequence randomly and encode it.
% 3. Use BPSK modulation, Let the modulated signal go through an AWGN channel.
% 4. Demodulate and LDPCdecode.
% 5. Calculate the bit-error rate errLDPC.
% 6. Disable LDPC codes, and run simulation again to collect the bit-error rate errbpsk.
% 7. Compare errLDPC and errbpsk


% Generate a parity check matrix and derive its generator matrix.
LDPCmaxiter=20;
getH;
H=colshift(H);
[m,n]=size(H);
k=n-m;
Hsys=getsysH(H);
G=getG(Hsys);
[GT_row,GT_rw,GT_cw,GT_maxrw,GT_maxcw]=mat2spar(G');
[H_row,H_rw,H_cw,H_maxrw,H_maxcw]=mat2spar(H);
H_col=sparmat_r2c(H_row,H_rw,H_cw,H_maxrw,H_maxcw,m,n);
% Set SNR in the AWGN channel
for SNRdB=0:0.5:10;
    SNR=10^(SNRdB/10);
    fn=0.2;
    simuiter=1000;
    errLDPC=0;
    % Run simulations for several times to collect the average bit-error rate.
    for i=1:simuiter
        % Generate a information sequence randomly and encode it.
        s=rand([k,1]);
        s=(s>0.5);
        t=LDPCencode(GT_row,s,GT_rw,k,n);
        % Use BPSK modulation
        wavetx=bpsk(t);
        % Let the modulated signal go through an AWGN channel
        waverx=awgn(wavetx,SNRdB);
        % BPSK demodulation
        r=dbpsk(waverx);
        % LDPC decode
        [t_est,iter]=LDPCdecode(r,H_row,H_col,H_rw,H_cw,m,n,fn,LDPCmaxiter);
        % Collect the bit-error rate.
        errLDPC=errLDPC+sum(t_est(1:k)~=t(1:k))/k;
    end
    errLDPC_List(SNRdB*2+1)=errLDPC/simuiter;

    % Disable LDPC codes, and run simulation again to collect the bit-error rate errbpsk.
    errbpsk=0;
    for i=1:simuiter
        s=rand([k,1]);
        s=(s>0.5);
        t=s;
        wavetx=bpsk(t);
        waverx=awgn(wavetx,SNRdB);
        r=dbpsk(waverx);
        errbpsk=errbpsk+sum(r(1:k)~=t(1:k))/k;
    end
    errbpsk_List(SNRdB*2+1)=errbpsk/simuiter;
end
figure(1);
subplot(2,1,1);
plot ([0:0.5:10],errLDPC_List,'o-',[0:0.5:10],errbpsk_List,'*-');
legend('with LDPC','without LDPC');
xlabel('SNR(dB)');
ylabel('BER');
title('BER under different SNRs (linear vertical axis)');

subplot(2,1,2);
semilogy ([0:0.5:6],errLDPC_List(1:13),'o-',[0:0.5:6],errbpsk_List(1:13),'*-');
legend('with LDPC','without LDPC');
xlabel('SNR(dB)');
ylabel('BER');
title('BER under different SNRs (semilogy)');