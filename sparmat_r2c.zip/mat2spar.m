% convert a normal matrix H to a sparse matrix.
% H_row: sparse matrix represented by column coordinate of non-zero entries for each row.
% rw: the row weight vector of H_row.
% cw: the column weight vector of H_row
% maxrw: the maximum entry in rw.
% maxcw: the maximum entry in cw.
% For example, if 
% H=[1,0,0,1,0
%    0,0,1,0,0]
% then H_row=[1,4  , H_rw=[2  , H_cw=[1,0,1,1,0]', maxrw=2, maxcw=1.
%             3,0]         1]

function [H_row,rw,cw,maxrw,maxcw]=mat2spar(H)
[m,n]=size(H);
rw=sum(H,2);
cw=sum(H,1)';
maxrw=max(rw);
maxcw=max(cw);
H_row=zeros(m,maxrw);
for i=1:m
    ind=1;
    for j=1:n
        if H(i,j)==1
           H_row(i,ind)=j;
           ind=ind+1;
        end
    end
end
return