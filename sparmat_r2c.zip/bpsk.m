% bpsk modulation

function wavetx=bpsk(t)
wavetx=ones(length(t),1);
wavetx(find(t==0))=-1;
return